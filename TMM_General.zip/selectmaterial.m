function n_output = selectmaterial(material, a, lambda0)
    mainpath = pwd;
    cd("Material DataBase\");

    x = lambda0(a)./1000;

    switch lower(material)
        case "air"
            n_output = 1;

        case "hfo2"
            n_output = 1.875 + 6.28e-3.*x.^-2 + 5.80e-4.*x.^-4;

        case "sin"
            load('nk_SiN_Vogt.mat');
            n_output = interp1(nk_SiN(:,1),nk_SiN(:,2),x') + ...
                       1i*interp1(nk_SiN(:,1),nk_SiN(:,3),x');

        case "si3n4"
            load('nk_Si3N4_ASRC.mat');
            n_output = interp1(nk_SiN(:,1),nk_SiN(:,2),x') + ...
                       1i*interp1(nk_SiN(:,1),nk_SiN(:,3),x') + 1i*0.0001;

        case "sio2"
            load('nk_SiO2_ASRC.mat');
            n_output = interp1(nk_SiO2(:,1),nk_SiO2(:,2),x') + ...
                       1i*interp1(nk_SiO2(:,1),nk_SiO2(:,3),x') + 1i*0.0001;

        case "zro2"
            n_output = sqrt(1+1.347091./(1-(0.062543./x).^2) + ...
                               2.117788./(1-(0.166739./x).^2) + ...
                               9.452943./(1-(24.320570./x).^2));

        case "nb2o5"
            load('nk_Na2O5_Lemarchand.mat');
            n_output = interp1(nk_Na2O5(:,1),nk_Na2O5(:,2),x') + ...
                       1i*interp1(nk_Na2O5(:,1),nk_Na2O5(:,3),x');

        case "tio2"
            load('nk_TiO2_stf.mat');
            n_output = interp1(nk_TiO2(:,1),nk_TiO2(:,2),x') + ...
                       1i*interp1(nk_TiO2(:,1),nk_TiO2(:,3),x');

        case "si"
            load('nk_Si_Schinke.mat');
            n_output = interp1(nk_Si(:,1),nk_Si(:,2),x') + ...
                       1i*interp1(nk_Si(:,1),nk_Si(:,3),x');

        case "ta2o5"
            load('nk_Ta2O5_Rodriguez.mat');
            n_output = interp1(nk_Ta2O5(:,1),nk_Ta2O5(:,2),x') + ...
                       1i*interp1(nk_Ta2O5(:,1),nk_Ta2O5(:,3),x');

        case "ge"
            load('nk_Ge_Ciesielski_2nm.mat');
            n_output = interp1(nk_Ge_Ciesielski_2nm(:,1),nk_Ge_Ciesielski_2nm(:,2),x') + ...
                       1i*interp1(nk_Ge_Ciesielski_2nm(:,1),nk_Ge_Ciesielski_2nm(:,3),x');

        case "ag"
            load('nk_Ag_Johnson.mat');
            n_output = interp1(nk_Ag_Johnson(:,1),nk_Ag_Johnson(:,2),x') + ...
                       1i*interp1(nk_Ag_Johnson(:,1),nk_Ag_Johnson(:,3),x');

        case "dye1"
            load('nk_dye_Evros.mat');
            n_output = interp1(nk_dye_Evros(:,1),nk_dye_Evros(:,2),x') + ...
                       1i*interp1(nk_dye_Evros(:,1),nk_dye_Evros(:,3),x');

        case "dye2"
            load('nk_dye_pm605tcnq.mat');
            n_output = interp1(nk_dye_pm605tcnq(:,1),nk_dye_pm605tcnq(:,2),x') + ...
                       1i*interp1(nk_dye_pm605tcnq(:,1),nk_dye_pm605tcnq(:,3),x');

        case "bk7"
            n_output = sqrt(1+1.03961212./(1-0.00600069867./x.^2)+ ...
                       0.231792344./(1-0.0200179144./x.^2)+ ...
                       1.01046945./(1-103.560653./x.^2));

        otherwise
            error('Unknown material: %s', material);
    end

    cd(mainpath);
end
