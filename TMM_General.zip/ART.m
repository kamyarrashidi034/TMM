function [Rs,Rp,Ts,Tp,Ms,Ds,Mp,Dp,kx,n,beta,P,d,k0] = ART(d,L,M,lambda0,theta0,n_structure)
    N   = numel(d);
    phi = zeros(1,N);
    kx  = zeros(1,N);
    Ds  = zeros(N,2,2);
    Dp  = zeros(N,2,2);
    P   = zeros(N,2,2);
    Rs  = zeros(L,M);
    Rp  = zeros(L,M);

    for a = 1:L 
        x  = lambda0(a)./1000;
        k0 = 2*pi./lambda0(a);
        n=[];
        for ii=1:numel(n_structure)
        n(ii)=selectmaterial(n_structure(ii),a,lambda0);
        end

        for b = 1:M
            beta = n(1)*k0*sin(theta0(b));
            Ms = eye(2);
            Mp = eye(2);

            for c = 1:N-1
                kx(c) = sqrt((n(c)*k0).^2 - beta.^2);
                ti = asin(n(1)*sin(theta0(b))/n(c));
                tt = asin(n(1)*sin(theta0(b))/n(c+1));

                Ds(c,:,:) = [(n(c)*cos(ti)+n(c+1)*cos(tt))/(2*n(c)*cos(ti)) (n(c)*cos(ti)-n(c+1)*cos(tt))/(2*n(c)*cos(ti));
                             (n(c)*cos(ti)-n(c+1)*cos(tt))/(2*n(c)*cos(ti)) (n(c)*cos(ti)+n(c+1)*cos(tt))/(2*n(c)*cos(ti))];

                Dp(c,:,:) = [(n(c+1)*cos(ti)+n(c)*cos(tt))/(2*n(c)*cos(ti)) (n(c+1)*cos(ti)-n(c)*cos(tt))/(2*n(c)*cos(ti));
                             (n(c+1)*cos(ti)-n(c)*cos(tt))/(2*n(c)*cos(ti)) (n(c+1)*cos(ti)+n(c)*cos(tt))/(2*n(c)*cos(ti))];

                phi(c) = kx(c).*d(c);
                P(c,:,:) = [exp(-1i*phi(c)) 0; 0 exp(1i*phi(c))];

                Ms = Ms*squeeze(P(c,:,:))*squeeze(Ds(c,:,:));
                Mp = Mp*squeeze(P(c,:,:))*squeeze(Dp(c,:,:));
            end

            Rs(a,b) = abs(Ms(2,1)./Ms(1,1)).^2;
            Rp(a,b) = abs(Mp(2,1)./Mp(1,1)).^2;

            theta_out = asin(n(1)*sin(theta0(b))/n(N));

            Ts(a,b) = (real(n(N)*cos(theta_out))/real(n(1)*cos(theta0(b)))) * abs(1./Ms(1,1)).^2;
            Tp(a,b) = (real(n(N)*cos(theta_out))/real(n(1)*cos(theta0(b)))) * abs(1./Mp(1,1)).^2;
        end
    end
end